package com.example.demo.movies.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.movies.entity.Movies;
import com.example.demo.movies.exception.MovieNotFoundException;
import com.example.demo.movies.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService {

    private final MovieRepository movieRepo;

    // Constructor for dependency injection
    public MovieServiceImpl(MovieRepository movieRepo) {
        this.movieRepo = movieRepo;
    }

    @Override
    public String addMovie(Movies movies) {
        Movies savedMovie = movieRepo.save(movies);
        if (savedMovie.getMovieId() != 0)  // Checks if the movie has been assigned an ID
            return "Movie Saved Successfully";  // Returns success message if movie is saved
        else
            return "Failed To Save Movie";  // Returns failure message if movie is not saved
    }

    @Override
    public Movies getMovie(int movieId) throws MovieNotFoundException {
        Optional<Movies> optional = movieRepo.findById(movieId);
        return optional.orElseThrow(() -> new MovieNotFoundException("Movie not found with ID: " + movieId));  // Throws exception if movie is not found
    }

    @Override
    public List<Movies> getAllMovies() {
        return movieRepo.findAll();  // Returns a list of all movies
    }

    @Override
    public String deleteMovie(int movieId) {
        movieRepo.deleteById(movieId);
        return "Movie Deleted Successfully";  // Returns success message if movie is deleted
    }

    @Override
    public Movies updateMovie(Movies movies) {
        Movies updatedMovie = movieRepo.save(movies);
        if (updatedMovie.getMovieId() != 0)  // Checks if the movie has been assigned an ID
            return updatedMovie;  // Returns the updated movie
        else
            return null;  // Returns null if movie is not updated
    }
}
